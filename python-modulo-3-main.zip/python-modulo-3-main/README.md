# tasks-flask-crud

Esse repositório foi criado durante o curso de Python na Rocketseat